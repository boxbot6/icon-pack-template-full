package com.example.iconpacktemplatefull

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.AssetManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView.OnItemClickListener
import android.widget.Button
import android.widget.GridView
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import java.io.File
import java.io.FileOutputStream
import java.io.IOException


class SecondFragment : Fragment() {
    private var dialog: Dialog? = null
    private var downloadPermissionGranted = false // initialised here to allow access from more locations
    private var globalClickedItemPosition = 0


    // specify a list of names for the clickable items in the grid
    private val namesList2 = arrayOf(
        "All Wallpapers",
        "Wallpaper 1",
        "Wallpaper 2",
        "Wallpaper 3",
        "Wallpaper 4",
        "Wallpaper 5",
        "Wallpaper 6",
        "Wallpaper 7",
        "Wallpaper 8"
    )

    // specify a list of the thumbnails that should be available from the res.drawable folder to match the above items
    private val imagesList2 = arrayOf(
        R.drawable.all_wallpapers_thumb,
        R.drawable.wallpaper1_thumb,
        R.drawable.wallpaper2_thumb,
        R.drawable.wallpaper3_thumb,
        R.drawable.wallpaper4_thumb,
        R.drawable.wallpaper5_thumb,
        R.drawable.wallpaper6_thumb,
        R.drawable.wallpaper7_thumb,
        R.drawable.wallpaper8_thumb
    )

    // specify a list for the html links from the assets folder when thumbnails are clicked
    private val linksList2 = arrayOf(
        "file:///android_asset/all_wallpapers.html",
        "file:///android_asset/wallpaper1.html",
        "file:///android_asset/wallpaper2.html",
        "file:///android_asset/wallpaper3.html",
        "file:///android_asset/wallpaper4.html",
        "file:///android_asset/wallpaper5.html",
        "file:///android_asset/wallpaper6.html",
        "file:///android_asset/wallpaper7.html",
        "file:///android_asset/wallpaper8.html"
    )

    // do this on result from permissions request
    private val requestMultiplePermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
        if (permissions[Manifest.permission.READ_MEDIA_IMAGES] == true ||
            permissions[Manifest.permission.WRITE_EXTERNAL_STORAGE] == true) {

            // PERMISSION GRANTED
            downloadPermissionGranted = true
            // change download button color here!
            val changeButtonColor: Button = dialog?.findViewById(R.id.buttonDownloadDialog1) as Button
            changeButtonColor.setBackgroundColor(-0x98af5d) // set color purple (active)
            Toast.makeText(activity, "Permission Granted", Toast.LENGTH_SHORT).show()
        } else {
            // PERMISSION NOT GRANTED
            downloadPermissionGranted = false
            // change download button color here!
            val changeButtonColor: Button = dialog?.findViewById(R.id.buttonDownloadDialog1) as Button
            changeButtonColor.setBackgroundColor(-0x9a9a9b) // set color grey (inactive)
            Toast.makeText(activity, "Permission Denied", Toast.LENGTH_SHORT).show()
        }
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val root = inflater.inflate(R.layout.fragment_2, container, false)

        // display the icons in gridView using SecondFragmentAdapter
        val gridView2 = root.findViewById<View>(R.id.grid_view2) as GridView

        val myAdapter2 = SecondFragmentAdapter(imagesList2, namesList2, requireContext())
        gridView2.adapter = myAdapter2
//        ViewCompat.setNestedScrollingEnabled(gridView2, true) // set scrollable
//        gridView2.stretchMode = GridView.STRETCH_COLUMN_WIDTH

        // handle item click in the grid view
        gridView2.onItemClickListener = OnItemClickListener { _, _, position2, _ ->

            // note which grid position image is clicked
            val clickedItemPosition = imagesList2[position2]
            // save image values from the item pressed to global variables
            globalClickedItemPosition = clickedItemPosition
//            showDialogBox(clickedItemPosition) // use this to show directly if not showing webView as below

            // display the associated webpage
            val webPageIntent2 = Intent(activity, SecondFragmentDisplayWebPage::class.java)
            webPageIntent2.putExtra("WEB_PAGE", linksList2[position2])
            resultLauncher.launch(webPageIntent2)
        }

        return root
    }

    // this method is called when the second activity finishes
    private var resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
//            // There are no request codes
//            val data: Intent? = result.data

            showDialogBox(globalClickedItemPosition)
        }
    }

    private fun showDialogBox(globalClickedItemPosition: Int) {
        dialog = Dialog(requireContext())
        dialog!!.setContentView(R.layout.fragment_2_display_dialog)

        // Remove dialog background by setting transparent and dimming to 0
        dialog!!.window!!.setBackgroundDrawableResource(android.R.color.transparent)
        dialog!!.window!!.setDimAmount(0f)

        // get px value (pixels) for 450dp (a reasonable dialog box size)
        val scale = resources.displayMetrics.density
        val pixels = (450 * scale + 0.5f).toInt()

        // get width of the screen in pixels
        val width = resources.displayMetrics.widthPixels

        // if screen is wider than the dialog box, limit the maximum size of the dialog to 450dp
        if (width > pixels) {
            dialog!!.window!!.setLayout(pixels, ViewGroup.LayoutParams.WRAP_CONTENT)
        } else { // if screen is narrower than the dialog box, fill the parent to ensure maximum dialog size
            dialog!!.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        // code to make prefix for the headings
        val dialog2PreText = dialog!!.findViewById<TextView>(R.id.textPrefixDialog2)
        dialog2PreText.text = getString(R.string.wallpaper_id)

        val dialog2Text = dialog!!.findViewById<TextView>(R.id.textDialog2)

        // code to make the headings using the drawable names

        // alt code to the one below it to extract only the name
//        // extract name (full path without extension converted to lowercase)
//        val title = resources.getResourceName(globalClickedItemPosition).lowercase()
//
//        val index = title.indexOf("/")
//        var name = (title)
//        // this shortens path to the index point and removes _thumb suffix by using .length - 6 for items with thumbnail versions
//        if (title.endsWith("_thumb")) {
//            name = title.substring(index + 1, title.length - 6)
//        }
//
//        // set id
//        dialog1Text.text = name // use this one to show name only

        // extract name and filetype
        val filetype = TypedValue()
        resources.getValue(globalClickedItemPosition, filetype, true)

        val fullStringWithFileType = filetype.string.toString().substring(13, filetype.string.toString().length).lowercase()
        // this removes any _thumb suffix by using replace
        val nameWithFileType = fullStringWithFileType.replace("_thumb", "")

        // set id
        dialog2Text.text = nameWithFileType // use this one to show name with extension

        // alt code to making the headings using the drawable names above - used to make headings from icon_pack.xml string-array "all" if added to values
//        TextView dialog1_text = dialog.findViewById(R.id.textDialog1);
//        // uses position from iconImage1 to call text from array all
//        String name = getResources().getStringArray(R.array.all)[position];
//        dialog1_text.setText(name);

        // code to show the image
        val dialog2Image = dialog!!.findViewById<ImageView>(R.id.imageDialog2)
        dialog2Image.setImageResource(globalClickedItemPosition)

        // close button
        val dialog2Close = dialog!!.findViewById<Button>(R.id.buttonCloseDialog2)
        dialog2Close.setOnClickListener { dialog!!.dismiss() }

        // download button
        val dialog2Download = dialog!!.findViewById<Button>(R.id.buttonDownloadDialog2)

        // initial check to see if permission to download is given and set download permissionGranted and button color accordingly
        if (Build.VERSION.SDK_INT >= 33) {
            downloadPermissionGranted = if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                dialog2Download.setBackgroundColor(-0x98af5d)
                true
            } else {
                dialog2Download.setBackgroundColor(-0x9a9a9b)
                false
            }
        } else {
            downloadPermissionGranted = if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                dialog2Download.setBackgroundColor(-0x98af5d)
                true
            } else {
                dialog2Download.setBackgroundColor(-0x9a9a9b)
                false
            }
        }


        dialog2Download.setOnClickListener {
            // if not already given request permissions
            if (!downloadPermissionGranted) {

                if (Build.VERSION.SDK_INT >= 33) {
                    requestMultiplePermissions.launch(
                        arrayOf(
//                        Manifest.permission.READ_MEDIA_AUDIO, // not used for this app
//                        Manifest.permission.READ_MEDIA_VIDEO, // not used for this app
                            Manifest.permission.READ_MEDIA_IMAGES // >= 33 you need to add any permission to allow saving files to internal Downloads
                        )
                    )
                } else {
                    requestMultiplePermissions.launch(
                        arrayOf(
//                        Manifest.permission.CAMERA, // not used for this app
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        )
                    )
                }
            } else {
                try {
                    onClickDownloadAssets(nameWithFileType)
                } catch (e: IOException) {
                    // throw RuntimeException(e)
                    // log the exception
                    Toast.makeText(activity, "Error Downloading $nameWithFileType, It Possibly Already Exists?", Toast.LENGTH_LONG).show()
                }

//                dialog!!.dismiss() // moved to onClickDownload1(name)
            }
        }

        dialog!!.show()
    }


    private fun onClickDownloadAssets(nameWithFileType: String) {
        var downloadName = nameWithFileType

        // the download file is found from the name of its clicked thumbnail image in the drawable folder (which can only have image .jpg .png or .xml types)
        //  - so a corresponding files have to be kept in the assets folder for download instead and are referenced here
        if (downloadName == "all_wallpapers.png") { // change this png download for a zip download
            downloadName = "all_wallpapers.zip"
        }
        // repeat above code for any other cases of files with unsupported file types that are stored in assets.

        val assetManager: AssetManager = requireContext().assets

        val `in` = assetManager.open(downloadName)
        try {
            val outFilePath = File(Environment.getExternalStorageDirectory().absolutePath + "/Download/")
            outFilePath.mkdirs()
            val outFile = File(outFilePath, downloadName) // (outFilePath, filename)
            val out = FileOutputStream(outFile)

            val buffer = ByteArray(1024)
            var bufferLength: Int
            while (`in`.read(buffer).also { bufferLength = it } > 0) {
                out.write(buffer, 0, bufferLength)
            }
            out.flush()
            out.close()
            // close the dialog
            dialog!!.dismiss()
            Toast.makeText(activity, "$downloadName Saved In Download Folder", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(activity, "Couldn't Save The Icon", Toast.LENGTH_LONG).show()
        }
    }


    companion object{
        fun newInstance() = SecondFragment()
    }


    override fun onResume() {
        super.onResume()
        // set this fragments name in the title bar
        (requireActivity() as MainActivity).supportActionBar?.title = "Wallpapers"
    }

}