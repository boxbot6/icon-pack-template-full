package com.example.iconpacktemplatefull

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.GridView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder


class ThirdFragment : Fragment() {

    private val namesList3 = arrayOf(
        "Nova Launcher",
        "KWGT Kustom Widget Maker",
        "KLWP Live Wallpaper Maker"
    )

    // specify a list of the thumbnails that should be available from the res.drawable folder
    private var imagesList3 = arrayOf(
        R.drawable.ic_nova,
        R.drawable.kwgt_kustom_widget_maker,
        R.drawable.klwp_live_wallpaper_maker
    )

    private val linksList3 = arrayOf(
        "https://novalauncher.com",
        "https://play.google.com/store/apps/details?id=org.kustom.widget&hl=en_GB&gl=US",
        "https://play.google.com/store/apps/details?id=org.kustom.wallpaper&hl=en&gl=US"
    )

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val root = inflater.inflate(R.layout.fragment_3, container, false)

        // display the icons in gridView using ThirdFragmentAdapter
        val gridView3 = root.findViewById<View>(R.id.icon_grid_view3) as GridView
        val myAdapter3 = ThirdFragmentAdapter(imagesList3, namesList3, requireContext())
        ViewCompat.setNestedScrollingEnabled(gridView3, true) // set scrollable
        gridView3.stretchMode = GridView.STRETCH_COLUMN_WIDTH

        gridView3.adapter = myAdapter3

        // handle item click in the grid view
        gridView3.onItemClickListener = AdapterView.OnItemClickListener { _, _, position3, _ ->

                MaterialAlertDialogBuilder(requireContext(), R.style.MaterialAlertDialog_rounded)
                    .setTitle("Do You Want To...")
                    .setMessage("Get This App?")
                    .setPositiveButton("YES") { _, _ ->
                        // OPEN WEBLINK
                        Toast.makeText(context, "You Clicked Get " + namesList3[position3], Toast.LENGTH_LONG).show()

                        var url = linksList3[position3]

                        if (!url.startsWith("http://") && !url.startsWith("https://")) {
                            url = "http://$url"
                        }

                        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        startActivity(browserIntent)
                    }
                    .setNegativeButton("CANCEL") { dialog, _ ->
                        // CLOSE DIALOG
                        dialog.dismiss()
                    }
                    .setCancelable(true)
                    .create()
                    .apply {
                        setCanceledOnTouchOutside(true)
                        show()
                    }
                }

        return root
    }

    companion object{
        fun newInstance() = ThirdFragment()
    }

    override fun onResume() {
        super.onResume()
        // set this fragments name in the title bar
        (requireActivity() as MainActivity).supportActionBar?.title = "Apps"
    }

}