package com.example.iconpacktemplatefull

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView


class FirstFragmentAdapter(list1: MutableList<Int>, private val mContext: Context) : BaseAdapter() {
    private var iconImagesList1 = list1


    override fun getCount(): Int {
        return iconImagesList1.size
    }

    override fun getItem(position: Int): Any? {
        return null
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val imageView: ImageView

        if (convertView == null) {
            imageView = ImageView(mContext)
            imageView.scaleType = ImageView.ScaleType.FIT_XY
            imageView.scaleType = ImageView.ScaleType.CENTER_INSIDE
            imageView.adjustViewBounds = true
            imageView.setPadding(12, 12, 12, 12) // was 8
        } else {
            imageView = convertView as ImageView
        }

        imageView.setImageResource(iconImagesList1[position])

        return imageView
    }

}