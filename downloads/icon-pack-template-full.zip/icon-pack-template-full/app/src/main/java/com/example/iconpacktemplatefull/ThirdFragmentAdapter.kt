package com.example.iconpacktemplatefull

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView


internal class ThirdFragmentAdapter(private val imagesList3: Array<Int>, private val namesList3: Array<String>, private val mContext: Context) : BaseAdapter() {

    private var layoutInflater: LayoutInflater? = null


    override fun getCount(): Int {
        return namesList3.size
    }

    override fun getItem(position: Int): Any? {
        return null
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getView(position: Int, view: View?, parent: ViewGroup?): View {
        var convertView = view

        if (layoutInflater == null) {
            layoutInflater = mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        }

        // on the below line we are checking if convertView is null - if it is null we are initializing it.
        if (convertView == null) {
            convertView = layoutInflater?.inflate(R.layout.fragment_3_grid_item, parent, false)
        }

        val itemImage3 = convertView?.findViewById(R.id.grid3ItemImage) as ImageView
        val itemText3 = convertView.findViewById<View>(R.id.grid3ItemText) as TextView

        itemImage3.setImageResource(imagesList3[position])
        itemText3.setLines(2)
        itemText3.text = namesList3[position]

        return convertView
    }

}