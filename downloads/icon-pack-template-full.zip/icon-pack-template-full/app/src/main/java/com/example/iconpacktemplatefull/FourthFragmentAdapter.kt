package com.example.iconpacktemplatefull

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView


class FourthFragmentAdapter(private val imagesList4: Array<Int>, private val namesList4: Array<String>, private val packageNamesList4: Array<String>, private val mContext: Context) : BaseAdapter() {
    private var layoutInflater: LayoutInflater? = null
    private var tagToOpenLauncherDialog = false
    private var tagToShowNotInstalledToast = false


    override fun getCount(): Int {
        return namesList4.size
    }

    override fun getItem(position: Int): Any? {
        return null
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getView(position: Int, view: View?, parent: ViewGroup?): View {

        var convertView = view

        if (layoutInflater == null) {
            layoutInflater =
                mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        }

        // on the below line we are checking if convert view is null - if it is null we are initializing it.
        if (convertView == null) {
            convertView = layoutInflater?.inflate(R.layout.fragment_4_grid_item, parent, false)
        }

        val itemImage4 = convertView?.findViewById(R.id.grid4ItemImage) as ImageView

        // make mutable list of suggested launchers list from packageNamesList4
        val installedLauncherNumberList = (0..(packageNamesList4.size)).toMutableList()

        // make a list of which launchers are installed and remove them from the list of launchers to be greyed-out
        installedLauncherNumberList.removeAll(findInstalledLaunchers().toSet()) // as Collection<Int>)

        // grey-out those launchers not available by reading from the installedLauncherNumberList
        for (i in 0 until installedLauncherNumberList.size) //installedLauncherNumberList.size)
        {
            if (position == installedLauncherNumberList[i]) {
                itemImage4.colorFilter =
                    ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
            }
        }

        val itemText4 = convertView.findViewById<View>(R.id.grid4ItemText) as TextView

        itemImage4.setImageResource(imagesList4[position])
        itemText4.setLines(2)
        itemText4.text = namesList4[position]

        return convertView
    }

    // fun findInstalledLaunchers(position: Int): MutableList<Any> {
    private fun findInstalledLaunchers(): MutableList<Any> {

        val result = mutableListOf<Any>()
        val pm: PackageManager = mContext.packageManager

        for (name in packageNamesList4) {
            val isInstalled: Boolean = isPackageInstalled(name, pm)

            if (isInstalled) {
                val i = packageNamesList4.indexOf(name)
                result.add(i)
                tagToOpenLauncherDialog = true // add qualifier for dialog to open launcher
            } else {
                tagToShowNotInstalledToast = true // add qualifier for dialog to show toast
            }
        }

        return result
    }

    private fun isPackageInstalled(packageName: String, packageManager: PackageManager): Boolean {
        return try {
            packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

}