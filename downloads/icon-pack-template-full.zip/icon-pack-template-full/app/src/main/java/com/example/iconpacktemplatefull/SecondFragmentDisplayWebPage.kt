package com.example.iconpacktemplatefull

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity


class SecondFragmentDisplayWebPage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_2_display_webpage)

        val page2 = intent
        val myPage2 = page2.getStringExtra("WEB_PAGE")
        val webView2 = findViewById<WebView>(R.id.webPageView2)
        webView2.webViewClient = MyWebViewClient()
        webView2.loadUrl(myPage2!!)
    }

    inner class MyWebViewClient : WebViewClient() {

        @Deprecated("Deprecated in Java")
        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            return if (url == "file:///android_asset/exit_trigger.html") {
                // create the response intent to pass back to the opening class and then close this activity
                val intent = Intent()
                setResult(RESULT_OK, intent)
                finish()
                true
            } else {
                Toast.makeText(this@SecondFragmentDisplayWebPage, "OVERRIDE NOT DETECTED", Toast.LENGTH_SHORT).show()
                view.loadUrl(url)
                true
            }
        }

        @RequiresApi(Build.VERSION_CODES.N)
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val url = request.url.toString()
            return if (url == "file:///android_asset/exit_trigger.html") {

                // create the response intent to pass back to the opening class and then close this activity
                val intent = Intent()
                setResult(RESULT_OK, intent)
                finish()
                true
            } else {
                Toast.makeText(this@SecondFragmentDisplayWebPage, "OVERRIDE NOT DETECTED", Toast.LENGTH_SHORT).show()
                view.loadUrl(url)
                true
            }
        }

    }

}