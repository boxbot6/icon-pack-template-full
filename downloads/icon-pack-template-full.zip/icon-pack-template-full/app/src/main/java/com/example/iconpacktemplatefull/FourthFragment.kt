package com.example.iconpacktemplatefull

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.GridView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder


class FourthFragment : Fragment() {

    // specify a list of names
    private val namesList4 = arrayOf(
        "Nova",
        "Action",
        "ADW",
        "ADW Ex",
        "Apex",
        "Atom",
        "Go",
        "Google Now",
        "Holo",
        "Holo ICS",
        "Lawnchair",
        "LG Home",
        "Lucid",
        "Moto",
        "Niagara",
        "OnePlus",
        "Pixel",
        "Posidon",
        "Smart",
        "Smart Pro",
        "Solo",
        "Square Home",
        "TSF"
    )

    // specify a list of the launcher icons that should be available from the res.drawable folder to match the above items
    private var imagesList4 = arrayOf(
        R.drawable.ic_nova,
        R.drawable.ic_action,
        R.drawable.ic_adw,
        R.drawable.ic_adw_ex,
        R.drawable.ic_apex,
        R.drawable.ic_atom,
        R.drawable.ic_go,
        R.drawable.ic_google_now,
        R.drawable.ic_holo,
        R.drawable.ic_holo_ics,
        R.drawable.ic_lawnchair,
        R.drawable.ic_lg,
        R.drawable.ic_lucid,
        R.drawable.ic_moto,
        R.drawable.ic_niagara,
        R.drawable.ic_oneplus,
        R.drawable.ic_pixel,
        R.drawable.ic_posidon,
        R.drawable.ic_smart,
        R.drawable.ic_smart_pro,
        R.drawable.ic_solo,
        R.drawable.ic_square,
        R.drawable.ic_tsf
    )

    // specify a list of launcher apps package names to check if installed
    private val packageNamesList4 = arrayOf(
        "com.teslacoilsw.launcher",
        "com.actionlauncher.playstore",
        "org.adw.launcher",
        "org.adwfreak.launcher",
        "com.anddoes.launcher",
        "com.dlto.atom.launcher",
        "com.gau.go.launcherex",
        "com.google.android.launcher",
        "com.mobint.hololauncher",
        "com.mobint.hololauncher.hd",
        "app.lawnchair",
        "com.lge.launcher3",
        "com.powerpoint45.launcher",
        "com.Motorola.launcher3",
        "bitpit.launcher",
        "net.oneplus.launcher",
        "com.google.android.apps.nexuslauncher",
        "posidon.launcher",
        "ginlemon.flowerfree",
        "ginlemon.flowerpro",
        "home.solo.launcher.free",
        "com.ss.squarehome2",
        "com.tsf.shell"
    )

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val root = inflater.inflate(R.layout.fragment_4, container, false)

        // display the icons in gridView using FourthFragmentAdapter
        val gridView4 = root.findViewById<View>(R.id.icon_grid_view4) as GridView
        gridView4.adapter = FourthFragmentAdapter(imagesList4, namesList4, packageNamesList4, requireContext())
        ViewCompat.setNestedScrollingEnabled(gridView4, true) // set scrollable
        gridView4.stretchMode = GridView.STRETCH_COLUMN_WIDTH

        // handle item click in the grid view
        gridView4.onItemClickListener = AdapterView.OnItemClickListener { _, _, position4, _ ->

                val pm: PackageManager = requireContext().packageManager

                if (isPackageInstalled(packageNamesList4[position4], pm)) {

//                    Toast.makeText(context, "You Clicked " + namesList4[position4], Toast.LENGTH_LONG).show()

                    MaterialAlertDialogBuilder(requireContext(), R.style.MaterialAlertDialog_rounded)
                        .setTitle("Do You Want To...")
                        .setMessage("Open This Launcher?")
                        .setPositiveButton("YES") { _, _ ->
                            // OPEN LAUNCHER
//                            Toast.makeText(context, "You Clicked To Open " + packageNamesList4[position4], Toast.LENGTH_LONG).show()


                            try {
                                val intent: Intent = pm.getLaunchIntentForPackage(packageNamesList4[position4])!!
                                intent.addCategory(Intent.CATEGORY_LAUNCHER)
                                startActivity(intent)
                                Toast.makeText(context, "Opening " + namesList4[position4], Toast.LENGTH_LONG).show()
                            } catch (_: PackageManager.NameNotFoundException) {
                                Toast.makeText(context, namesList4[position4] + " Is Not Installed On This Device..", Toast.LENGTH_LONG).show()
//                                Toast.makeText(context, packageNamesList4[position4] + "app is not installed2", Toast.LENGTH_LONG).show()
                            }



                        }
                        .setNegativeButton("CANCEL") { dialog, _ ->
                            // CLOSE DIALOG
                            dialog.dismiss()
                        }
                        .setCancelable(true)
                        .create()
                        .apply {
                            setCanceledOnTouchOutside(true)
                            show()
                        }

                } else {
                    Toast.makeText(context, namesList4[position4] + " Is Not Installed On This Device..", Toast.LENGTH_LONG).show()
                }
            }
        return root
    }

    private fun isPackageInstalled(packageName: String, packageManager: PackageManager): Boolean {
        return try {
            packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    companion object {
        fun newInstance() = FourthFragment()
    }

    override fun onResume() {
        super.onResume()
        // set this fragments name in the title bar
        (requireActivity() as MainActivity).supportActionBar?.title = "Launchers"
    }

}