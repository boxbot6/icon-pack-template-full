package com.example.iconpacktemplatefull

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView


internal class SecondFragmentAdapter(private val imagesList2: Array<Int>, private val namesList2: Array<String>, private val mContext: Context) : BaseAdapter() {

    private var layoutInflater: LayoutInflater? = null


    override fun getCount(): Int {
        return namesList2.size
    }

    override fun getItem(position: Int): Any? {
        return null
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getView(position: Int, view: View?, parent: ViewGroup?): View {
        var convertView = view

        if (layoutInflater == null) {
            layoutInflater = mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        }

        // below we are checking if convertView is null - if it is null we are initializing it.
        if (convertView == null) {
            convertView = layoutInflater?.inflate(R.layout.fragment_2_single_grid_item, parent, false)
        }

        val itemImage2 = convertView?.findViewById(R.id.grid2ItemImage) as ImageView
        val itemText2 = convertView.findViewById<View>(R.id.grid2ItemText) as TextView

        itemImage2.setImageResource(imagesList2[position])
        itemText2.setLines(2)
        itemText2.text = namesList2[position]

        return convertView
    }

}