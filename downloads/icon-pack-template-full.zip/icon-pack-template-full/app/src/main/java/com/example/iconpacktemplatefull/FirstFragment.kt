package com.example.iconpacktemplatefull

import android.Manifest
import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.storage.StorageManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.Button
import android.widget.GridView
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity.*
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.fragment.app.Fragment
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Objects


class FirstFragment : Fragment() {
    private var dialog: Dialog? = null // initialised here to allow access from more locations
    private var downloadPermissionGranted = false // initialised here to allow access from more locations
    private var globalClickedItemPosition = 0 // initialised here to allow access from more locations


    // do this on result from permissions request
    private val requestMultiplePermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
        if (permissions[Manifest.permission.READ_MEDIA_IMAGES] == true ||
            permissions[Manifest.permission.WRITE_EXTERNAL_STORAGE] == true) {
            // PERMISSION GRANTED
            downloadPermissionGranted = true
            // change download button color here!
            val changeButtonColor: Button = dialog?.findViewById(R.id.buttonDownloadDialog1) as Button
            changeButtonColor.setBackgroundColor(-0x98af5d) // set color purple (active)
            Toast.makeText(activity, "Permission Granted", Toast.LENGTH_SHORT).show()
        } else {
            // PERMISSION NOT GRANTED
            downloadPermissionGranted = false
            // change download button color here!
            val changeButtonColor: Button = dialog?.findViewById(R.id.buttonDownloadDialog1) as Button
            changeButtonColor.setBackgroundColor(-0x9a9a9b) // set color grey (inactive)
            Toast.makeText(activity, "Permission Denied", Toast.LENGTH_SHORT).show()
        }
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {

        val root = inflater.inflate(R.layout.fragment_1, container, false)

        // get a list of the icons to be used from the res.drawable folder by parsing the drawable.xml file from the xml folder
        // the xml folder file drawable.xml is also used by Nova Launcher etc. to get the icons
        val parser = resources.getXml(R.xml.drawable)
        val list1: MutableList<Int> = ArrayList()
        try {
            while (parser.next() != XmlPullParser.END_DOCUMENT) {
                if (parser.eventType == XmlPullParser.START_TAG && parser.name == "item") {
                    for (i in 0 until parser.attributeCount) {
                        if (parser.getAttributeName(i) == "drawable") {
                            val convertedToDrawableResource =
                                "@drawable/" + parser.getAttributeValue(0)
                            val drawableResourceId = this.resources.getIdentifier(
                                convertedToDrawableResource,
                                "drawable",
                                requireActivity().packageName
                            )
                            list1.add(drawableResourceId)
                        }
                    }
                }
            }
        } catch (e: XmlPullParserException) {
            e.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }


        // display the icons in gridView using FirstFragmentAdapter
        val gridView = root.findViewById<GridView>(R.id.icon_grid_view1)
        gridView.adapter = FirstFragmentAdapter(list1, requireContext())
        ViewCompat.setNestedScrollingEnabled(gridView, true) // set scrollable
        gridView.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        gridView.onItemClickListener =
            AdapterView.OnItemClickListener { _, _, position1, _ ->
                val clickedItemPosition = list1[position1]
                globalClickedItemPosition = clickedItemPosition
            showDialogBox(clickedItemPosition)
        }

        return root
    }


    @SuppressLint("ObsoleteSdkInt")
    private fun showDialogBox(clickedItemPosition: Int) {
        dialog = Dialog(requireContext())
        dialog!!.setContentView(R.layout.activity_main_dialog1)

        // remove dialog background by setting transparent and dimming to 0
        dialog!!.window!!.setBackgroundDrawableResource(android.R.color.transparent)
        dialog!!.window!!.setDimAmount(0f)

        // get px value (pixels) for 450dp (a reasonable dialog box size)
        val scale = resources.displayMetrics.density
        val pixels = (450 * scale + 0.5f).toInt()

        // get width of the screen in pixels
        val width = resources.displayMetrics.widthPixels

        // if screen is wider than the dialog box, limit the maximum size of the dialog to 450dp
        if (width > pixels) {
            dialog!!.window!!.setLayout(pixels, ViewGroup.LayoutParams.WRAP_CONTENT)
        } else { // if screen is narrower than the dialog box, fill the parent to ensure maximum dialog size
            dialog!!.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        // code to make prefix for the headings
        val dialog1PreText = dialog!!.findViewById<TextView>(R.id.textPrefixDialog1)
        dialog1PreText.text = getString(R.string.icon_id)

        // code to make the headings using the drawable names
        val dialog1Text = dialog!!.findViewById<TextView>(R.id.textDialog1)
        val title = resources.getResourceName(clickedItemPosition)

        // extracting name
        val index = title.indexOf("/")
        val name = title.substring(index + 1, title.length)
        dialog1Text.text = name

/*
//        // alt code to above - to make headings from icon_pack.xml string-array "all" if added to values
//        TextView dialog1_text = dialog.findViewById(R.id.textDialog1);
//        // uses position from iconImage1 to call text from array all
//        String name = getResources().getStringArray(R.array.all)[position];
//        dialog1_text.setText(name);
*/

        // code to show the image
        val dialog1Image = dialog!!.findViewById<ImageView>(R.id.imageDialog1)
        dialog1Image.setImageResource(clickedItemPosition)

        // close button
        val dialog1Close = dialog!!.findViewById<Button>(R.id.buttonCloseDialog1)
        dialog1Close.setOnClickListener { dialog!!.dismiss() }

        // download button
        val dialog1Download = dialog!!.findViewById<Button>(R.id.buttonDownloadDialog1)
        // initial check to see if permission to download is given and set download permissionGranted and button color accordingly
        if (Build.VERSION.SDK_INT >= 33) {
            downloadPermissionGranted = if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                dialog1Download.setBackgroundColor(-0x98af5d)
                true
            } else {
                dialog1Download.setBackgroundColor(-0x9a9a9b)
                false
            }
        } else {
            downloadPermissionGranted = if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                dialog1Download.setBackgroundColor(-0x98af5d)
                true
            } else {
                dialog1Download.setBackgroundColor(-0x9a9a9b)
                false
            }
        }


        dialog1Download.setOnClickListener {
            // if not already given request permissions
            if (!downloadPermissionGranted) {

                if (Build.VERSION.SDK_INT >= 33) {
                    requestMultiplePermissions.launch(
                        arrayOf(
//                        Manifest.permission.READ_MEDIA_AUDIO, // not used for this app
//                        Manifest.permission.READ_MEDIA_VIDEO, // not used for this app
                            Manifest.permission.READ_MEDIA_IMAGES // if >= 33 you need to add any permission here to also allow saving files to internal downloads folder
                        )
                    )
                } else {
                    requestMultiplePermissions.launch(
                        arrayOf(
//                        Manifest.permission.CAMERA, // not used for this app
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        )
                    )
                }
            } else {
                try {
                    onClickDownload1(name)
                } catch (e: IOException) {
                    // throw RuntimeException(e)
                    // log the exception
                    Toast.makeText(activity, "Error Downloading $name, It Possibly Already Exists?", Toast.LENGTH_LONG).show()
                }

//                dialog!!.dismiss() // moved to onClickDownload1(name)
            }
        }

        dialog!!.show()
    }


    private fun onClickDownload1(name: String) {
        val downloadName = "$name.png"
        val downloadResource = "@drawable/$name"
        val drawableResourceId = this.resources.getIdentifier(downloadResource, "drawable", requireActivity().packageName)

        val o = BitmapFactory.Options()
        o.inScaled = false // convert image to bitmap without the automatic rescaling
        val bitmapInputImage = BitmapFactory.decodeResource(this.resources, drawableResourceId, o)
        val byteArrayOutputStream = ByteArrayOutputStream()
        bitmapInputImage.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)
        val bytesArray = byteArrayOutputStream.toByteArray()
        try {
            val fileOutput: File = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) { // possibly use Build.VERSION_CODES.N instead
                val storageManager = requireActivity().getSystemService(STORAGE_SERVICE) as StorageManager
                val storageVolume = storageManager.storageVolumes[0] // internal storage

                File(Objects.requireNonNull((storageVolume.directory)?.path) + "/Download/" + downloadName)
            } else {
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), downloadName)
            }
            val fileOutputStream = FileOutputStream(fileOutput)
            fileOutputStream.write(bytesArray)
            fileOutputStream.flush()
            fileOutputStream.close()
            // close the dialog
            dialog!!.dismiss()
            Toast.makeText(activity, "$downloadName Saved In Download Folder", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(activity, "Couldn't Save The Icon", Toast.LENGTH_LONG).show()
        }
    }


    companion object {
        fun newInstance() = FirstFragment()
    }


    override fun onResume() {
        super.onResume()
        // set this fragments name in the title bar
        (requireActivity() as MainActivity).supportActionBar?.title = "Icons"
    }


}